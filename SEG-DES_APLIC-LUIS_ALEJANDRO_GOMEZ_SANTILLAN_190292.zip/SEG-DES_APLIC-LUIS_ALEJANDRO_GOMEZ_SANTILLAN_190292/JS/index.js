// //Api fallina 
// const token= 409792597568009
// const API_URL= 'https://superheroapi.com/api/409792597568009/385';
// fetch(API_URL)
//     .then(response => response.json())
//      .then(data =>{
//          let element = document.getElementById('app')
//         element.innerHTML = 
//          `<p>${data.name}</p>
//          <img src='${data.image}'></img>`
        
//         ;
//          console.log(data)
//      })
//      .catch(err=>console.log(err))

//API
 const API_URL= 'https://pokeapi.co/api/v2/pokemon/3/';
    
   fetch(API_URL)
     .then(response => response.json())
     .then(data =>{
         let element = document.getElementById('app')
         element.innerHTML = 
         `<p>${data.name}</p>
         <img src='${data.sprites.front_default}'></img>`
        
         ;
         console.log(data)
     })
     .catch(err=>console.log(err))


