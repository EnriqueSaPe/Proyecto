const API_URL= 'https://pokeapi.co/api/v2/pokemon/3/';
    
fetch(API_URL)
  .then(response => response.json())
  .then(data =>{
      let element = document.getElementById('container')
      element.innerHTML = 
      `<p>${data.name}</p>
      <img src='${data.sprites.front_default}'></img>`
     
      ;
      console.log(data)
  })
  .catch(err=>console.log(err))
