<h1>Lista de Clientes</h1>

<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Matrícula</th>
      <th scope="col">Tipo</th>
      <th scope="col">Marca</th>
      <th scope="col">Modelo</th>
      <th scope="col">Color</th>
      <th scope="col">Puertas</th>
      <th scope="col">Estatus</th>
      <th scope="col">Cliente</th>
      <th scope="col">Registro</th>
      <th scope="col">Eliminar | Editar</th>
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($vehiculo->id_vehiculo); ?></td>
      <td><?php echo e($vehiculo->matricula); ?></td>
      <td><?php echo e($vehiculo->tipo); ?></td>
      <td><?php echo e($vehiculo->marca); ?></td>
      <td><?php echo e($vehiculo->modelo); ?></td>
      <td><?php echo e($vehiculo->color); ?></td>
      <td><?php echo e($vehiculo->puertas); ?></td>
      <td><?php echo e($vehiculo->status); ?></td>
      <td><?php echo e($vehiculo->id_cliente); ?></td>
      <td><?php echo e($vehiculo->fechareg); ?></td>
    </tr>
    </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table><?php /**PATH E:\DESARROLLO\Autolavado\Autolavado\resources\views/Vehiculo/listVehiculo.blade.php ENDPATH**/ ?>