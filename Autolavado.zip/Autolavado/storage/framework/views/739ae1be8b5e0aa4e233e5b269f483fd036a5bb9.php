<h1>Lista de Clientes</h1>

<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Descripción</th>
      <th scope="col">Costo</th>
      <th scope="col">status</th>
      <th scope="col">Eliminar | Editar</th>
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row">1</th>
      <td><?php echo e($servicio->id_servicio); ?></td>
      <td><?php echo e($servicio->description); ?></td>
      <td><?php echo e($servicio->costo); ?></td>
      <td><?php echo e($servicio->status); ?></td>
      <td><?php echo e($servicio->fechareg); ?></td>
    </tr>
    </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table><?php /**PATH D:\DESARROLLO\Autolavado\Autolavado\resources\views/Servicios/listServicio.blade.php ENDPATH**/ ?>