<h1>Lista de Clientes</h1>

<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Fecha</th>
      <th scope="col">Vehiculo</th>
      <th scope="col">Cajero</th>
      <th scope="col">Servicio</th>
      <th scope="col">Trabajador</th>
      <th scope="col">Estatus</th>
      <th scope="col">Eliminar | Editar</th>
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($venta->id_venta); ?></td>
      <td><?php echo e($venta->fecha); ?></td>
      <td><?php echo e($venta->id_vehiculo); ?></td>
      <td><?php echo e($venta->id_cajero); ?></td>
      <td><?php echo e($venta->id_servicio); ?></td>
      <td><?php echo e($venta->id_trabajador); ?></td>
      <td><?php echo e($venta->status); ?></td>
    </tr>
    </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table><?php /**PATH E:\DESARROLLO\Autolavado\Autolavado\resources\views/Ventas/listVenta.blade.php ENDPATH**/ ?>