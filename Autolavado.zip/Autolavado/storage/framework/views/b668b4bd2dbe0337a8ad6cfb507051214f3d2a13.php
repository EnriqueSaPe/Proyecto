<h1>Lista de Clientes</h1>

<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nombre</th>
      <th scope="col">Apellido</th>
      <th scope="col">Apellido</th>
      <th scope="col">Direccion</th>
      <th scope="col">Teléfono</th>
      <th scope="col">Correo</th>
      <th scope="col">Tipo</th>
      <th scope="col">Eliminar | Editar</th>
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $trabajadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($trabajador->id_trabajador); ?></td>
      <td><?php echo e($trabajador->nombre); ?></td>
      <td><?php echo e($trabajador->apaterno); ?></td>
      <td><?php echo e($trabajador->amaterno); ?></td>
      <td><?php echo e($trabajador->direccion); ?></td>
      <td><?php echo e($trabajador->telefono); ?></td>
      <td><?php echo e($trabajador->correo); ?></td>
      <td><?php echo e($trabajador->tipo); ?></td>
    </tr>
    </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table><?php /**PATH E:\DESARROLLO\Autolavado\Autolavado\resources\views/Trabajadores/listTrabajador.blade.php ENDPATH**/ ?>